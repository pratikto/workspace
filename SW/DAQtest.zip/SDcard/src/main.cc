#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
/*
 * Several BSP (and standard C) header files need to be included
 */
#include <stdlib.h> 		// Standard C functions, e.g. exit()
#include <stdbool.h> 		// Provides a Boolean data type for ANSI/ISO-C
#include "xparameters.h" 	// Parameter definitions for processor peripherals
#include "xscugic.h" 		// Processor interrupt controller device driver
#include "xscutimer.h"		//private timer
#include "xsdps.h"
#include "ff.h"
#include "xplatform_info.h"
#include "xil_cache.h"
#include <string>

int main(){
	print("Program to test communication with HLS madgwick peripheral in PL\n");
	//variable for access SD card
	static FATFS FS_instance; // File System instance
	static FIL file1;		// File instance
	FRESULT result;			// FRESULT variable
	static char *FileName = "test1.txt"; // name of the log
	static char *Log_File; // pointer to the log
	char *Path = "0:/";  //  string pointer to the logical drive number
	unsigned int BytesWr; // Bytes written
	static unsigned int len=0;			// length of the string
	static unsigned int accum=0;		//  variable holding the EOF
	char *Buffer_logger __attribute__ ((aligned(32))); // Buffer should be word aligned (multiple of 4)

	// Mount SD Card and initialize device
	result = f_mount(&FS_instance,Path, 1);
	if (result != 0) {
		print("SD card initialization failed\n\r");
		return XST_FAILURE;
	}

	// Creating new file with read/write permissions
	Log_File = (char *)FileName;
	result = f_open(&file1, Log_File, FA_CREATE_ALWAYS | FA_WRITE | FA_READ);
	if (result!= 0) {
		print("failed creating new files\n\r");
		return XST_FAILURE;
	}

	for(int i=0; i<10; i++){

		sprintf(Buffer_logger, "Test-%d!\n", i);
		print(Buffer_logger);

	   	// Open log for writing
//		Log_File = (char *)FileName;
//		result = f_open(&file1, Log_File,FA_WRITE);
//			if (result!=0) {
//				return XST_FAILURE;
//			}

		// Point to the end of log
		result = f_lseek(&file1,accum);
			if (result!=0) {
				return XST_FAILURE;
			}

		// Increment file EOF pointer
		len = strlen(Buffer_logger);
		accum=accum+len;

		// Write to log
		result = f_write(&file1, (const void*)Buffer_logger, len, &BytesWr);
		if (result!=0) {
			return XST_FAILURE;
		}

//		 //Close file.
//		result = f_close(&file1);
//		if (result!=0) {
//			return XST_FAILURE;
//		}
	}

	//Close file.
	result = f_close(&file1);
	if (result!=0) {
		return XST_FAILURE;
	}

	return 0;
}
